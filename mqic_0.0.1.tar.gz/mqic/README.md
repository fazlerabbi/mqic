mqic
====
